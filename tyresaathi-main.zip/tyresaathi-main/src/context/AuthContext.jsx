import React, { createContext, useContext, useState, useEffect } from "react";
import { auth, db } from "../firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged, 
  sendPasswordResetEmail 
} from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";

export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  VENDOR: "vendor"
};

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [role, setRole] = useState("user");
  const [loading, setLoading] = useState(true);

  // Login
  function login(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  // Register
  function signup(email, password) {
    return createUserWithEmailAndPassword(auth, email, password);
  }

  // Logout
  function logout() {
    setUserData(null);
    setRole("user");
    return signOut(auth);
  }

  // Reset Password
  function resetPassword(email) {
    return sendPasswordResetEmail(auth, email);
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          // Firestore se user data lane ki koshish
          const userDoc = await getDoc(doc(db, "users", user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUserData(data);
            setRole(data.role || "user");
          } else {
            setUserData({ email: user.email, role: "user" });
            setRole("user");
          }
        } catch (err) {
          console.error("Firestore user fetch error:", err);
          // Agar firestore block bhi kare, tab bhi app crash na ho
          setUserData({ email: user.email, role: "user" });
          setRole("user");
        }
      } else {
        setUserData(null);
        setRole("user");
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value = {
    currentUser,
    userData,
    role,
    login,
    signup,
    logout,
    resetPassword,
    isAdmin: role === "admin" || role === ROLES.ADMIN,
    isVendor: role === "vendor" || role === ROLES.VENDOR
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
