import React from "react";
import { Menu, Moon, Sun } from "lucide-react";
import { useTheme } from "../context/ThemeContext.jsx";

export default function Navbar({ onMenuClick }) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="navbar">
      <div className="navbar-left">
        <button className="icon-btn menu-btn" onClick={onMenuClick} aria-label="Menu">
          <Menu size={22} />
        </button>
        <span className="navbar-brand brand-font">TyreSaathi</span>
      </div>

      <button className="icon-btn theme-toggle" onClick={toggleTheme} aria-label="Toggle dark mode">
        {theme === "dark" ? <Sun size={19} /> : <Moon size={19} />}
      </button>

      <style>{`
        .navbar {
          height: 58px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 14px;
          background: var(--surface);
          border-bottom: 1px solid var(--border);
          position: sticky;
          top: 0;
          z-index: 30;
        }
        .navbar-left { display: flex; align-items: center; gap: 10px; }
        .navbar-brand { font-size: 20px; color: var(--text); }
        .icon-btn {
          background: none;
          border: none;
          cursor: pointer;
          color: var(--text);
          display: flex;
          align-items: center;
          justify-content: center;
          width: 36px;
          height: 36px;
          border-radius: 10px;
        }
        .icon-btn:hover { background: var(--surface-2); }
        .menu-btn { display: flex; }
        @media (min-width: 900px) {
          .menu-btn { display: none; }
        }
      `}</style>
    </header>
  );
}
