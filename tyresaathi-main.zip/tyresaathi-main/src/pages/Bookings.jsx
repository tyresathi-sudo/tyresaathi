import React from "react";
import PlaceholderCard from "../components/PlaceholderCard.jsx";

export default function Bookings() {
  return (
    <div>
      <h1 className="brand-font page-title">Bookings</h1>
      <PlaceholderCard
        title="Booking System"
        note="Ye Phase 5 (Booking System) me Tyre Cut Repair, Puncture Repair, Doorstep Service jaise booking types ke saath banega — Pending / Accepted / In Progress / Completed / Cancelled status ke saath."
      />
      <style>{`.page-title { font-size: 24px; margin: 0 0 16px; }`}</style>
    </div>
  );
}
