import React from "react";
import PlaceholderCard from "../components/PlaceholderCard.jsx";

export default function Search() {
  return (
    <div>
      <h1 className="brand-font page-title">Search</h1>
      <PlaceholderCard
        title="Tyre Search"
        note="Ye Phase 3 (Customer App) me brand, size aur nearby shops ke hisaab se search banega."
      />
      <style>{`.page-title { font-size: 24px; margin: 0 0 16px; }`}</style>
    </div>
  );
}
