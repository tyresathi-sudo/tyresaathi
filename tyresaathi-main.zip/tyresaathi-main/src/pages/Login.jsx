import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export function friendlyError(code) {
  if (typeof code === "string" && (code.includes("offline") || code.includes("unavailable"))) {
    return "Network connection issue. Please check your internet.";
  }
  switch (code) {
    case "auth/invalid-email":
      return "Invalid email format.";
    case "auth/user-not-found":
    case "auth/invalid-credential":
      return "Incorrect email or password.";
    case "auth/wrong-password":
      return "Incorrect password.";
    case "auth/email-already-in-use":
      return "An account with this email already exists.";
    case "auth/weak-password":
      return "Password must be at least 6 characters long.";
    case "auth/too-many-requests":
      return "Too many failed attempts. Please try again later.";
    case "auth/unauthorized-domain":
      return "Domain not authorized in Firebase Console.";
    default:
      return code ? `Error: ${code}` : "Something went wrong. Please try again.";
  }
}

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    e.stopPropagation();
    setError("");
    setLoading(true);

    try {
      // 10 सेकंड का सेफ टाइमआउट
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Request timed out. Please try again.")), 10000)
      );

      // सिर्फ एक बार लॉगिन कॉल होगा
      await Promise.race([login(email.trim(), password), timeoutPromise]);

      // React Router के ज़रिए स्मूथ नेविगेशन (कोई हार्ड रीलोड नहीं)
      navigate("/", { replace: true });
    } catch (err) {
      console.error("Firebase Login Error:", err);
      setError(friendlyError(err.code || err.message));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h1 className="brand-font auth-title">Login</h1>
        <p className="auth-sub">Welcome back to TyreSaathi</p>

        {error && (
          <div
            style={{
              color: "#fff",
              background: "#d9534f",
              padding: "10px",
              borderRadius: "6px",
              marginBottom: "15px",
              fontSize: "14px",
              textAlign: "center"
            }}
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="auth-field">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              autoComplete="email"
            />
          </div>

          <div className="auth-field">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />
          </div>

          <button className="auth-btn" disabled={loading} type="submit">
            {loading ? "कृपया प्रतीक्षा करें..." : "Login"}
          </button>
        </form>

        <div className="auth-links" style={{ marginTop: "15px", display: "flex", justifyContent: "space-between" }}>
          <Link to="/forgot-password">Forgot Password?</Link>
          <Link to="/register">Create a new account</Link>
        </div>
      </div>
    </div>
  );
}
