import React from "react";
import { useNavigate } from "react-router-dom";
import { Moon, Sun, LogOut, Phone, Mail, Store, ShieldCheck } from "lucide-react";
import { useTheme } from "../context/ThemeContext.jsx";
import { useAuth, ROLES } from "../context/AuthContext.jsx";

const ROLE_LABEL = {
  [ROLES.CUSTOMER]: "Customer",
  [ROLES.SHOP_OWNER]: "Shop Owner",
  [ROLES.ADMIN]: "Admin",
};

export default function Profile() {
  const { theme, toggleTheme } = useTheme();
  const { profile, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/login", { replace: true });
  }

  return (
    <div>
      <h1 className="brand-font page-title">Profile</h1>

      <div className="profile-card">
        <div className="profile-avatar">{profile?.name ? profile.name[0].toUpperCase() : "?"}</div>
        <div className="profile-name">{profile?.name || "..."}</div>
        <div className="profile-role">
          {ROLE_LABEL[profile?.role] || "..."}
          {profile?.role === ROLES.SHOP_OWNER && profile?.shopName ? ` · ${profile.shopName}` : ""}
        </div>
        {profile?.phone && <div className="profile-row"><Phone size={14} /> {profile.phone}</div>}
        {profile?.email && <div className="profile-row"><Mail size={14} /> {profile.email}</div>}
        {profile?.role === ROLES.SHOP_OWNER && (
          <div className="profile-row">
            <ShieldCheck size={14} />
            {profile.shopApproved ? "Shop approved hai" : "Shop abhi admin approval ka wait kar raha hai"}
          </div>
        )}
      </div>

      <div className="settings-row">
        <span>Dark Mode</span>
        <button className="theme-switch" onClick={toggleTheme}>
          {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
          {theme === "dark" ? "Light Mode" : "Dark Mode"}
        </button>
      </div>

      <button className="secondary-btn full" onClick={handleLogout} style={{ marginTop: 8 }}>
        <LogOut size={15} style={{ verticalAlign: "middle", marginRight: 6 }} />
        Logout
      </button>

      <style>{`
        .page-title { font-size: 24px; margin: 0 0 16px; }
        .profile-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 16px;
          padding: 24px;
          text-align: center;
          margin-bottom: 16px;
        }
        .profile-avatar {
          width: 56px; height: 56px; border-radius: 50%;
          background: var(--orange); color: white;
          display: flex; align-items: center; justify-content: center;
          font-size: 22px; font-weight: 700; margin: 0 auto 10px;
        }
        .profile-name { font-size: 18px; font-weight: 700; }
        .profile-role { color: var(--text-muted); font-size: 13px; margin-bottom: 10px; }
        .profile-row {
          display: flex; align-items: center; gap: 6px; justify-content: center;
          font-size: 13px; color: var(--text-muted); margin-top: 4px;
        }
        .settings-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 12px;
          padding: 14px 16px;
          margin-bottom: 14px;
          font-weight: 600;
          font-size: 14px;
        }
        .theme-switch {
          display: flex;
          align-items: center;
          gap: 6px;
          background: var(--surface-2);
          border: none;
          border-radius: 100px;
          padding: 7px 14px;
          font-weight: 700;
          font-size: 12.5px;
          cursor: pointer;
          color: var(--text);
        }
        .secondary-btn.full {
          width: 100%;
          background: var(--surface-2);
          color: var(--danger);
          border: none;
          border-radius: 10px;
          padding: 12px;
          font-weight: 700;
          font-size: 14px;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}
