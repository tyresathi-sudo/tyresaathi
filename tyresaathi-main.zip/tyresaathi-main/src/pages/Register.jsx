import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth, ROLES } from "../context/AuthContext.jsx";
import { friendlyError } from "./Login.jsx";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [role, setRole] = useState(ROLES.CUSTOMER);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [shopName, setShopName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (role === ROLES.SHOP_OWNER && !shopName.trim()) {
      setError("Dukan ka naam daalna zaroori hai.");
      return;
    }

    setLoading(true);
    try {
      await register({
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim(),
        password,
        role,
        shopName: shopName.trim(),
      });
      navigate("/", { replace: true });
    } catch (err) {
      setError(friendlyError(err.code));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h1 className="brand-font auth-title">Account Banayein</h1>
        <p className="auth-sub">Customer ho ya Shop Owner, dono chun sakte hain</p>

        {error && <div className="auth-error">{error}</div>}

        <div className="role-pick">
          <button
            type="button"
            className={"role-btn" + (role === ROLES.CUSTOMER ? " role-btn-active" : "")}
            onClick={() => setRole(ROLES.CUSTOMER)}
          >
            Customer
          </button>
          <button
            type="button"
            className={"role-btn" + (role === ROLES.SHOP_OWNER ? " role-btn-active" : "")}
            onClick={() => setRole(ROLES.SHOP_OWNER)}
          >
            Shop Owner
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="auth-field">
            <label>Naam</label>
            <input value={name} onChange={(e) => setName(e.target.value)} required placeholder="Aapka naam" />
          </div>
          <div className="auth-field">
            <label>Phone Number</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              placeholder="98765 43210"
            />
          </div>
          {role === ROLES.SHOP_OWNER && (
            <div className="auth-field">
              <label>Dukan ka Naam</label>
              <input
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="Jaise: Raja Tyre Center"
              />
            </div>
          )}
          <div className="auth-field">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="aapka@email.com"
              autoComplete="email"
            />
          </div>
          <div className="auth-field">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              placeholder="Kam se kam 6 characters"
              autoComplete="new-password"
            />
          </div>
          <button className="auth-btn" disabled={loading}>
            {loading ? "Ruko..." : "Account Banayein"}
          </button>
        </form>

        <div className="auth-links" style={{ justifyContent: "center" }}>
          <Link to="/login">Pehle se account hai? Login karein</Link>
        </div>
      </div>
    </div>
  );
}
