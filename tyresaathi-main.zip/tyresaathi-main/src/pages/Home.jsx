import React from "react";
import PlaceholderCard from "../components/PlaceholderCard.jsx";

export default function Home() {
  return (
    <div>
      <h1 className="brand-font page-title">Namaste 👋</h1>
      <p className="page-sub">TyreSaathi ka naya version ban raha hai — phase by phase.</p>
      <PlaceholderCard
        title="Home Screen"
        note="Ye Phase 3 (Customer App) me nearby shops, tyre search aur banners ke saath poora banega."
      />

      <style>{`
        .page-title { font-size: 26px; margin: 0 0 4px; }
        .page-sub { color: var(--text-muted); margin: 0 0 20px; font-size: 14px; }
      `}</style>
    </div>
  );
}
