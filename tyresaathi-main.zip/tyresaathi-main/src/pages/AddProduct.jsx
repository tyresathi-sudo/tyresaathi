import React, { useEffect, useState } from "react";
import { addDoc, collection, doc, getDocs, serverTimestamp, updateDoc } from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../firebase";
import { useAuth } from "../context/AuthContext";
import { useNavigate, useParams } from "react-router-dom";

// 🌟 आपके सारे प्रोडक्ट टाइप्स
const PRODUCT_TYPES = [
  { id: "tyre", label: "🆕 Tyre (टायर)" },
  { id: "tube", label: "⭕ Tube (ट्यूब)" },
  { id: "flap", label: "◉ Flap (फ्लैप)" },
  { id: "patch", label: "🩹 Patch (पैच)" },
  { id: "gater", label: "🔧 Gater (गेटर)" },
  { id: "custom", label: "🛠️ Customize (कस्टम सामान)" },
  { id: "service", label: "🛠️ Repair & Service (सर्विस)" },
];

export default function AddProduct() {
  const { user, profile } = useAuth();
  const { id } = useParams();
  const navigate = useNavigate();
  const edit = Boolean(id);

  const [nodes, setNodes] = useState([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  // 🌟 कंबाइंड स्मार्ट फॉर्म स्टेट (दोनो कोड्स का मिक्स)
  const [form, setForm] = useState({
    productType: "tyre", 
    condition: "new", // 'new' या 'old'
    categoryId: "", vehicleTypeId: "", brandId: "", sizeId: "", modelId: "",
    productName: "", description: "", images: [],
    // ⬇️ एक्स्ट्रा डिटेल्स
    tyreType: "Tubeless", warranty: "", tubeSize: "", valveType: "TR", tubeMaterial: "",
    flapSize: "", flapType: "", patchType: "", patchSize: "", patchMaterial: "",
    gaterSize: "", gaterType: "", customDetails: "", serviceName: "", serviceDuration: "",
    originalPrice: "", offerPrice: "", stock: "1", published: true,
  });

  useEffect(() => {
    async function loadCatalog() {
      try {
        const snapshot = await getDocs(collection(db, "catalogNodes"));
        const data = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
        setNodes(data);
      } catch (error) {
        console.error("Catalog error:", error);
      } finally {
        setLoading(false);
      }
    }
    loadCatalog();
  }, []);

  // 🎯 स्मार्ट फिल्टरिंग
  const categories = nodes.filter((n) => n.type === "category");
  const vehicleTypes = nodes.filter((n) => n.type === "vehicleType" && n.parentId === form.categoryId);
  const brands = nodes.filter((n) => n.type === "brand" && n.parentId === form.vehicleTypeId);
  const sizes = nodes.filter((n) => n.type === "size" && n.parentId === form.brandId);
  const models = nodes.filter((n) => n.type === "model" && n.parentId === form.sizeId);
  const getName = (id) => nodes.find((n) => n.id === id)?.name || "";

  const updateField = (field, value) => {
    setForm((prev) => {
      const newForm = { ...prev, [field]: value };
      if (field === "productType") { newForm.productName = ""; }
      if (field === "categoryId") { newForm.vehicleTypeId = ""; newForm.brandId = ""; newForm.sizeId = ""; newForm.modelId = ""; }
      if (field === "vehicleTypeId") { newForm.brandId = ""; newForm.sizeId = ""; newForm.modelId = ""; }
      if (field === "brandId") { newForm.sizeId = ""; newForm.modelId = ""; }
      if (field === "sizeId") { newForm.modelId = ""; }
      return newForm;
    });
  };

  const discountPercent = (() => {
    const mrp = Number(form.originalPrice);
    const offer = Number(form.offerPrice);
    return (mrp > 0 && offer > 0 && mrp > offer) ? Math.round(((mrp - offer) / mrp) * 100) : 0;
  })();

  // 📸 मल्टीपल फोटो अपलोड
  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length || !user) return;
    setUploading(true);
    try {
      const urls = [];
      for (const file of files) {
        const storageRef = ref(storage, `products/${user.uid}/${Date.now()}-${file.name}`);
        await uploadBytes(storageRef, file);
        urls.push(await getDownloadURL(storageRef));
      }
      setForm((prev) => ({ ...prev, images: [...prev.images, ...urls] }));
    } catch (error) {
      alert("Image upload failed: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const removeImage = (indexToRemove) => {
    setForm((prev) => ({ ...prev, images: prev.images.filter((_, idx) => idx !== indexToRemove) }));
  };

  const handleSubmit = async (event, isDraft = false) => {
    event.preventDefault();
    if (!user?.uid) return alert("Please login.");
    
    // वैलिडेशन
    const finalProductName = form.productType === "service" ? form.serviceName : form.productName;
    if (!finalProductName.trim()) return alert("Product / Service Name डालना जरूरी है!");

    setSaving(true);
    try {
      const productData = {
        ...form,
        productName: finalProductName,
        categoryName: getName(form.categoryId) || "Other",
        vehicleTypeName: getName(form.vehicleTypeId),
        brandName: getName(form.brandId),
        sizeName: getName(form.sizeId),
        modelName: getName(form.modelId),
        originalPrice: Number(form.originalPrice || 0),
        offerPrice: Number(form.offerPrice || 0),
        stock: form.productType === "service" ? 999 : Number(form.stock || 0),
        published: !isDraft,
        shopId: user.uid,
        shopName: profile?.shopName || "TyreSaathi Shop",
        updatedAt: serverTimestamp(),
      };

      if (edit) {
        await updateDoc(doc(db, "products", id), productData);
        alert(isDraft ? "📝 Draft Saved!" : "✅ Updated!");
      } else {
        await addDoc(collection(db, "products"), { ...productData, createdAt: serverTimestamp() });
        alert(isDraft ? "📝 Draft Saved!" : "🚀 Published!");
      }
      navigate("/profile");
    } catch (error) {
      alert("Error saving data: " + error.message);
    } finally {
      setSaving(false);
    }
  };

  const showCatalogDropdowns = ["tyre", "tube", "flap"].includes(form.productType);

  if (loading) return <div style={{ padding: "20px", textAlign: "center" }}>Loading...</div>;

  return (
    <div style={{ padding: "20px", maxWidth: "1050px", margin: "0 auto", color: "#333", fontFamily: "sans-serif" }}>
      <h2 style={{ borderBottom: "2px solid #f39c12", paddingBottom: "10px", marginBottom: "20px" }}>
        {edit ? "✏️ Edit Details" : "➕ Add to Shop"}
      </h2>

      <div style={{ display: "flex", gap: "30px", flexWrap: "wrap", alignItems: "flex-start" }}>
        
        {/* 📝 बायां हिस्सा: स्मार्ट फॉर्म */}
        <form style={{ flex: "1", minWidth: "350px", display: "flex", flexDirection: "column", gap: "15px", background: "#f8f9fa", padding: "20px", borderRadius: "8px", border: "1px solid #e0e0e0" }}>
          
          <label style={{ fontWeight: "bold" }}>1. What are you adding? *</label>
          <select value={form.productType} onChange={(e) => updateField("productType", e.target.value)} style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc", background: "white" }}>
            {PRODUCT_TYPES.map((type) => <option key={type.id} value={type.id}>{type.label}</option>)}
          </select>

          {/* Condition Dropdown (सिर्फ सामान के लिए) */}
          {form.productType !== "service" && form.productType !== "custom" && (
            <select value={form.condition} onChange={(e) => updateField("condition", e.target.value)} style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc", background: "white" }}>
              <option value="new">🆕 Brand New (नया)</option>
              <option value="old">♻️ Second Hand (पुराना)</option>
            </select>
          )}

          {/* 🎯 स्मार्ट ड्रॉपडाउन्स (Category, Vehicle, Brand...) */}
          {showCatalogDropdowns && (
            <div style={{ display: "flex", flexDirection: "column", gap: "10px", background: "white", padding: "15px", borderRadius: "5px", border: "1px solid #eee" }}>
              <label style={{ fontSize: "14px", fontWeight: "bold" }}>Select Catalog Details</label>
              
              <select value={form.categoryId} onChange={(e) => updateField("categoryId", e.target.value)} style={{ padding: "8px", borderRadius: "5px", border: "1px solid #ccc" }}>
                <option value="">Select Category</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>

              {form.categoryId && vehicleTypes.length > 0 && (
                <select value={form.vehicleTypeId} onChange={(e) => updateField("vehicleTypeId", e.target.value)} style={{ padding: "8px", borderRadius: "5px", border: "1px solid #ccc" }}>
                  <option value="">Select Vehicle (Bike, Car...)</option>
                  {vehicleTypes.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
                </select>
              )}

              {form.vehicleTypeId && brands.length > 0 && (
                <select value={form.brandId} onChange={(e) => updateField("brandId", e.target.value)} style={{ padding: "8px", borderRadius: "5px", border: "1px solid #ccc" }}>
                  <option value="">Select Brand</option>
                  {brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              )}

              {form.brandId && sizes.length > 0 && (
                <select value={form.sizeId} onChange={(e) => updateField("sizeId", e.target.value)} style={{ padding: "8px", borderRadius: "5px", border: "1px solid #ccc" }}>
                  <option value="">Select Size</option>
                  {sizes.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              )}

              {form.sizeId && models.length > 0 && (
                <select value={form.modelId} onChange={(e) => updateField("modelId", e.target.value)} style={{ padding: "8px", borderRadius: "5px", border: "1px solid #ccc" }}>
                  <option value="">Select Model / Pattern</option>
                  {models.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              )}
            </div>
          )}

          <label style={{ fontWeight: "bold", marginTop: "10px" }}>2. Specific Details *</label>
          
          {/* 🚦 डायनामिक फील्ड्स (Tyre, Tube, Patch के हिसाब से) */}
          {form.productType === "tyre" && (
             <div style={{display:"flex", gap:"10px"}}>
               <input type="text" value={form.productName} onChange={(e) => updateField("productName", e.target.value)} required placeholder="Product Title (e.g. MRF Zapper)" style={{ flex:1, padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
               <select value={form.tyreType} onChange={(e) => updateField("tyreType", e.target.value)} style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }}>
                 <option>Tubeless</option><option>Tube Type</option>
               </select>
             </div>
          )}

          {form.productType === "tube" && (
             <div style={{display:"flex", flexDirection:"column", gap:"10px"}}>
               <input type="text" value={form.productName} onChange={(e) => updateField("productName", e.target.value)} required placeholder="Title (e.g. MRF Tube 90/90)" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
               <div style={{display:"flex", gap:"10px"}}>
                 <input type="text" value={form.tubeSize} onChange={(e) => updateField("tubeSize", e.target.value)} placeholder="Tube Size" style={{ flex:1, padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
                 <select value={form.valveType} onChange={(e) => updateField("valveType", e.target.value)} style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }}>
                   <option>TR</option><option>TR4</option><option>TR87</option><option>Other</option>
                 </select>
               </div>
             </div>
          )}

          {form.productType === "flap" && (
             <div style={{display:"flex", flexDirection:"column", gap:"10px"}}>
               <input type="text" value={form.productName} onChange={(e) => updateField("productName", e.target.value)} required placeholder="Flap Name" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
               <input type="text" value={form.flapSize} onChange={(e) => updateField("flapSize", e.target.value)} placeholder="Flap Size" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
             </div>
          )}

          {form.productType === "patch" && (
             <div style={{display:"flex", flexDirection:"column", gap:"10px"}}>
               <input type="text" value={form.productName} onChange={(e) => updateField("productName", e.target.value)} required placeholder="Patch Name" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
               <div style={{display:"flex", gap:"10px"}}>
                 <input type="text" value={form.patchType} onChange={(e) => updateField("patchType", e.target.value)} placeholder="Type" style={{ flex:1, padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
                 <input type="text" value={form.patchSize} onChange={(e) => updateField("patchSize", e.target.value)} placeholder="Size" style={{ flex:1, padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
               </div>
             </div>
          )}

          {form.productType === "service" && (
             <div style={{display:"flex", flexDirection:"column", gap:"10px"}}>
               <input type="text" value={form.serviceName} onChange={(e) => updateField("serviceName", e.target.value)} required placeholder="Service Name (e.g. Cut Repair)" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
               <input type="text" value={form.serviceDuration} onChange={(e) => updateField("serviceDuration", e.target.value)} placeholder="Time Taken (e.g. 30 mins)" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
             </div>
          )}

          {["gater", "custom"].includes(form.productType) && (
             <input type="text" value={form.productName} onChange={(e) => updateField("productName", e.target.value)} required placeholder="Product Title" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
          )}

          <textarea value={form.description} onChange={(e) => updateField("description", e.target.value)} placeholder="Extra Description / Warranty details..." rows="2" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc", resize: "none" }} />

          <label style={{ fontWeight: "bold", marginTop: "10px" }}>3. Pricing & Stock *</label>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <span style={{ fontSize: "12px", color: "#666" }}>MRP (₹)</span>
              <input type="number" value={form.originalPrice} onChange={(e) => updateField("originalPrice", e.target.value)} placeholder="Original Price" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
            </div>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <span style={{ fontSize: "12px", color: "green", fontWeight: "bold" }}>Offer Price (₹) *</span>
              <input type="number" value={form.offerPrice} onChange={(e) => updateField("offerPrice", e.target.value)} required placeholder="Selling Price" style={{ padding: "10px", borderRadius: "5px", border: "2px solid #27ae60" }} />
            </div>
          </div>

          {form.productType !== "service" && (
             <div style={{ display: "flex", flexDirection: "column", width: "100%", marginTop: "5px" }}>
                <span style={{ fontSize: "12px", color: "#666" }}>Stock Quantity *</span>
                <input type="number" value={form.stock} onChange={(e) => updateField("stock", e.target.value)} required placeholder="Kitne piece hain?" style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ccc" }} />
             </div>
          )}

          <div style={{ display: "flex", gap: "10px", marginTop: "15px" }}>
            <button type="button" onClick={(e) => handleSubmit(e, true)} disabled={saving || uploading} style={{ flex: "1", padding: "12px", background: "#e0e0e0", color: "#333", border: "none", borderRadius: "5px", cursor: "pointer", fontWeight: "bold" }}>
              📝 Save Draft
            </button>
            <button type="button" onClick={(e) => handleSubmit(e, false)} disabled={saving || uploading} style={{ flex: "2", padding: "12px", background: "#f39c12", color: "white", border: "none", borderRadius: "5px", cursor: "pointer", fontWeight: "bold" }}>
              {saving ? "⏳ Publishing..." : "🚀 Publish Now"}
            </button>
          </div>
        </form>

        {/* 📱 दायां हिस्सा: लाइव प्रीव्यू (Meesho Style) */}
        <div style={{ flex: "1", minWidth: "300px", maxWidth: "350px", position: "sticky", top: "20px" }}>
          <div style={{ background: "white", padding: "20px", borderRadius: "8px", border: "1px solid #e0e0e0", boxShadow: "0 4px 12px rgba(0,0,0,0.08)" }}>
            <h4 style={{ margin: "0 0 15px 0", color: "#333", fontSize: "16px", borderBottom: "1px solid #eee", paddingBottom: "10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span>👁️ Customer Preview</span>
              <span style={{ fontSize: "12px", color: "#888" }}>Live</span>
            </h4>
            
            {/* 📸 फोटो अपलोड बॉक्स (Multiple Supported) */}
            <label style={{ width: "100%", height: "180px", background: "#f2f4f5", borderRadius: "8px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#999", marginBottom: "10px", cursor: "pointer", border: "2px dashed #ccc", overflow: "hidden", position: "relative" }}>
               <input type="file" accept="image/*" multiple onChange={handleImageUpload} style={{ display: "none" }} />
               
               {uploading ? (
                 <span style={{ fontSize: "14px", color: "#f39c12", fontWeight: "bold" }}>⏳ Uploading...</span>
               ) : form.images.length > 0 ? (
                 <img src={form.images[0]} alt="Preview" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
               ) : (
                 <>
                   <span style={{ fontSize: "30px" }}>📸</span>
                   <span style={{ fontSize: "13px", marginTop: "5px", color: "#333", fontWeight: "500" }}>Click to Add Photos</span>
                 </>
               )}
            </label>

            {/* छोटे फोटो थंबनेल (अगर 1 से ज्यादा फोटो डाली हैं) */}
            {form.images.length > 0 && (
              <div style={{ display: "flex", gap: "8px", marginBottom: "15px", overflowX: "auto", paddingBottom: "5px" }}>
                {form.images.map((imgUrl, index) => (
                  <div key={index} style={{ position: "relative", minWidth: "50px", height: "50px", borderRadius: "4px", overflow: "hidden", border: "1px solid #ddd" }}>
                    <img src={imgUrl} alt="thumb" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    <button type="button" onClick={() => removeImage(index)} style={{ position: "absolute", top: 0, right: 0, background: "rgba(255,0,0,0.7)", color: "white", border: "none", borderRadius: "0 0 0 4px", fontSize: "10px", cursor: "pointer", padding: "2px 4px" }}>X</button>
                  </div>
                ))}
              </div>
            )}

            <h3 style={{ fontSize: "18px", margin: "0 0 8px 0", color: "#111", lineHeight: "1.3" }}>
              {form.productType === "service" ? (form.serviceName || "Service Title...") : (form.productName || "Product Title...")}
            </h3>
            
            <div style={{ display: "flex", alignItems: "baseline", gap: "8px", marginBottom: "12px" }}>
               <span style={{ fontSize: "24px", fontWeight: "bold", color: "#27ae60" }}>₹{form.offerPrice || "0"}</span>
               {Number(form.originalPrice) > Number(form.offerPrice) && (
                 <span style={{ fontSize: "14px", textDecoration: "line-through", color: "#999" }}>₹{form.originalPrice}</span>
               )}
               {discountPercent > 0 && (
                 <span style={{ fontSize: "12px", background: "#e74c3c", color: "white", padding: "3px 6px", borderRadius: "4px", fontWeight: "bold" }}>{discountPercent}% OFF</span>
               )}
            </div>

            <div style={{ background: "#f8f9fa", padding: "10px", borderRadius: "6px", fontSize: "13px", color: "#555" }}>
                <p style={{ margin: "0 0 5px 0", fontWeight: "bold", color: "#333" }}>🏷️ {PRODUCT_TYPES.find(t => t.id === form.productType)?.label}</p>
                {form.productType !== "service" && form.productType !== "custom" && (
                   <p style={{ margin: "0 0 5px 0" }}>{form.condition === "new" ? "🆕 Condition: Brand New" : "♻️ Condition: Second Hand"}</p>
                )}
                {form.productType !== "service" && (
                  <p style={{ margin: "0", color: form.stock > 0 ? "#27ae60" : "#e74c3c", fontWeight: "bold" }}>
                    {form.stock > 0 ? `✅ ${form.stock} in Stock` : "❌ Out of Stock"}
                  </p>
                )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
