import { Home, Search, Calendar, User } from "lucide-react";

// Phase 1: generic placeholder routes. Phase 2/3 onwards these will become
// real Customer / Shop Owner / Admin routes once auth + roles exist.
export const NAV_ITEMS = [
  { to: "/", label: "Home", icon: Home, end: true },
  { to: "/search", label: "Search", icon: Search },
  { to: "/bookings", label: "Bookings", icon: Calendar },
  { to: "/profile", label: "Profile", icon: User },
];
