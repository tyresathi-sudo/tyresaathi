import React from "react";
import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";
import Home from "./pages/Home.jsx";
import Search from "./pages/Search.jsx";
import Bookings from "./pages/Bookings.jsx";
import Profile from "./pages/Profile.jsx";
import NotFound from "./pages/NotFound.jsx";
// 👇 ये नई लाइन जोड़ दी गई है
import AddProduct from "./pages/AddProduct.jsx";

// Phase 2: Login/Register/Forgot Password are public.
// Everything else requires login (ProtectedRoute wraps the shared Layout).
// Phase 3/4/7 will add allowRoles={["shop_owner"]} etc. to split by role.
export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      <Route
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Home />} />
        <Route path="/search" element={<Search />} />
        <Route path="/bookings" element={<Bookings />} />
        <Route path="/profile" element={<Profile />} />
        
        {/* 👇 ये नई लाइनें (Add और Edit दोनों के लिए) जोड़ दी गई हैं */}
        <Route path="/shop/add-product" element={<AddProduct />} />
        <Route path="/shop/edit-product/:id" element={<AddProduct />} />

        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
